# Matchday

A soccer watch planner built for a cybersecurity lab. Includes 12 competitions, team search, date and league filters, U.S. broadcaster listings when available, browser-local saved matches, time-zone selection (Mountain Time by default), and calendar downloads.

## Publish on GitHub Pages

1. Use a public GitHub repository for free GitHub Pages hosting. If using the empty `gageyoung` repository, change its visibility under **Settings → General → Danger Zone → Change repository visibility**. The code and files become public.
2. Upload this folder's **contents**, so `index.html` is at the repository root. Include `data`, `scripts`, and `.github/workflows/update.yml`. Hidden folders may require enabling hidden items in File Explorer. Do not upload the ZIP itself.
3. Under **Settings → Pages**, select **GitHub Actions** as the source.
4. Under **Actions**, select **Refresh soccer schedules → Run workflow** on `main`. If GitHub requests permission to enable Actions, enable it for this repository. The workflow needs read/write contents permission to commit refreshed data.
5. When the workflow finishes, open the deployment URL under **Settings → Pages**. For `gageyoung11/gageyoung`, the expected address is `https://gageyoung11.github.io/gageyoung/`.

The workflow refreshes data and republishes approximately every six hours. Scheduled workflows can be delayed and GitHub may disable them in inactive public repositories after 60 days. Re-enable or run manually under Actions. No API keys are required.

## Preview locally

Serve this directory with a local static web server (for example VS Code's Live Server extension). Double-clicking index.html will not load the JSON data because browsers restrict local file fetches.

## Data and limitations

- Schedules and U.S. geoBroadcast listings come from ESPN's publicly accessible scoreboard endpoints. These are unofficial, undocumented integrations with no availability guarantee; this project is not affiliated with ESPN. If access or terms change, replace the data adapter in `scripts/update-schedules.mjs`.
- The snapshot includes today and the next seven UTC dates. Local dates may differ. The interface labels the last refresh and warns about old or partial data.
- Coverage is not exhaustive. A missing fixture or channel does not mean a game is unavailable. No channel is inferred from general league rights. Viewing links point to service landing pages or listings, not guaranteed match streams. Verify language, subscription and regional availability before kickoff.
- ESPN remains the source of fixtures; refresh failures retain earlier matching records with labels. If all requests fail, the script fails without overwriting the last successful snapshot.
- Saved matches stay in this browser and do not sync between devices. No login, tracking, or private credentials. Google Fonts is optional; system fonts work offline.
- Calendar events use a two-hour placeholder duration and do not update automatically when fixtures change.

## Files

- `index.html`, `style.css`, `app.js`: website.
- `data/schedule.json`: generated schedule snapshot.
- `scripts/update-schedules.mjs`: refresh adapter, requires Node.js 22+.
- `.github/workflows/update.yml`: automatic refresh and GitHub Pages deployment.
